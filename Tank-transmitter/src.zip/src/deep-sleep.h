#pragma once

#include <Arduino.h>


void deep_sleep_init();
void deep_sleep(uint16_t sec);