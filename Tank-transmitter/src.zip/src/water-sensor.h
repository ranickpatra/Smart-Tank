#pragma once

#include <Arduino.h>

void water_sensor_init();

uint8_t water_sensor_read_water_level();