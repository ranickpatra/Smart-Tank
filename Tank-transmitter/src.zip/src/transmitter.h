#pragma once

#include <Arduino.h>

void transmitter_init();

void transmitter_send(uint8_t data);